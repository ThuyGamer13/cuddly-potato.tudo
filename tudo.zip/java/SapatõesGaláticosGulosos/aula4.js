/*
    COMANDO        RETORNO

    .length        tamanho da string
    .charAt(5)     caractere no índice
    .indexOf('a')  indice do caractere
    .slice(3,8)    intervalo de caracteres
    .toUpperCase() caixa alta
    .toLowerCase() caixa baixa
    .trim()        limpa espaços nao intencionais
    .split(' ')    fatia a string
    .includes('a') confere se tem determinado texto
*/

function soyouthinkyoucanStonemeandSpitinMyEye(){
    texto = document.getElementById('tro').value

    tamanho = texto.length
    primeira = texto.charAt(0)

    document.getElementById('gru-po').innerText =
    'O seu texto tem '+tamanho+' caracteres e começa com '+primeira+'.'
}