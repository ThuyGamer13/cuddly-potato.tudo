function validarSabores(){
    code = 'Gucci'
    input = document.getElementById('gucci').value
    no = 'voce errou mano, lembre que a senha vem antes de morty.'
    ye = 'voce acertou mano, parabens, vc é muito tuffox, ganhou aura inf'
    if(code != input){
        document.getElementById('morty').innerText = no
    } else{
        document.getElementById('morty').innerText = ye
    }

}

function verifDrip(){
    val = Number(document.getElementById('num').value)
    frase_pos = 'TEU DRIP É POSITIVO, GAJO.'
    frase_neg = 'retire-se de minha moradia gajo, ou serás vasectomizado.'
    frase_neu = 'teu drip é neutro, tem aura pois nao perdeu nem ganhou.'
    if(val > 0 && val < 50 ){
        document.getElementById('resposta').innerText = frase_pos
    } else if(val < 0){
        document.getElementById('resposta').innerText = frase_neg
    } else if(val > 50){
        document.getElementById('resposta').innerText = 'gajo, substituirás o próprio rei gucci morty, orgulhe-se rapariga.'
    } else{
        document.getElementById('resposta').innerText = frase_neu
    }
    
}