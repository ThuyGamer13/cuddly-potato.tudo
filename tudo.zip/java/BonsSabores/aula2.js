function bonsSabores(){
   nome = document.getElementById('name').value
   frase = 'boas vindas '+nome+'!'
   document.getElementById('whigger').innerText = frase
}

function numSahur(){
    n1 = Number(document.getElementById('num1').value);
    n2 = Number(document.getElementById('num2').value);
    soma = n1 + n2
    frase = 'sua soma é '+soma+'.'
    document.getElementById('numerosabor').innerText = frase
}