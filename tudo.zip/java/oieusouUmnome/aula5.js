function oiEusouumaFunao(){
    lados = Number(document.getElementById('texto').value)
    mariadala = Math.floor(Math.random() * lados) + 1
    document.getElementById('value').innerText = 'Oio resulatoé '+mariadala+'.'
    if(mariadala == 1){
        document.getElementById('value').innerText += ' TU É MUITO BETA VIADOOOKKKKK'
    }
    if(mariadala == lados){
        document.getElementById('value').innerText += ' TU É MUITO TUFF VIADOOOKKKKK'
    }

}

function oiCasiaxQuiaoi(){
    txt = document.getElementById("caixaoi").value
    document.getElementById("caixaoi").value = ''
    document.getElementById('caixa').innerHTML += '<span>'+txt+'<span>'
}