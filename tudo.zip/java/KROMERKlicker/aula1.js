//alert("eai meu 67 bacanudo abacatudo moranguete 42?")
//document.write('<h1>Olá Crioulos!!</h1>')
//console.log('Olá Crioulos!')

nome = 'Arthur'
idade = 12
//document.write('<p>Olá ' ,nome, ', você tem ' ,idade, ' anos. </p>')

a = 6
b = 7

//Ex 1
//document.write('<b>numeros: ', a ,' e ', b ,'</b>')
//document.write('<br>Adição: ', a+b)
//document.write('<br>Subtração: ', a-b)
//document.write('<br>Multiplicação: ', a+b)
//document.write('<br>Divisão: ', a/b)
//Ex 2
//document.write(
    '<b>numeros: ', a ,' e ', b ,'</b>' +
    '<br>Adição: ', (a+b) +
    '<br>Subtração: ', (a-b) +
    '<br>Multiplicação: ', (a*b) +
    '<br>Divisão: ', (a/b)  
//)
//document.write(
    'para usar "or", escreva "||"'
    'para usar "and", escreva "&&" '
//)
KROMER = 0

function getKromer(){
    KROMER += 1
    //alert('+'+KROMER+' [[KROMER]]!')
   p = document.getElementById('msg').innerText = '+'+KROMER+' [[KROMER]]!'
}

